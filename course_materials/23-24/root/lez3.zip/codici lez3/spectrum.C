void spectrum(){
    //Creo istogramma
    TH1F *hist = new TH1F("hist", "Istogramma", 100, -5, 5);
    hist->FillRandom("gaus", 10000);

    // Creo un oggetto TSpectrum
    TSpectrum *s = new TSpectrum();

    // Cerco i picchi nell'istogramma
    double sigma = 2;
    double threshold = 0.05;
    //const char *option = "nobackground";
    int nfound = s->Search(hist, sigma, "", threshold);
    
    
    // Ottiene le posizioni x y dei picchi trovati
    double *xpeaks = s->GetPositionX();
    double *ypeaks = s->GetPositionY();


    // Stampa la posizione di ogni picco trovato
    std::cout<<"Picchi trovati:"<<nfound<<"\n";
    std::cout<<"x \t y\n";
    for (Int_t i = 0; i < nfound; i++) {
        std::cout<< xpeaks[i] << "\t" << ypeaks[i] << "\n";
    }
    hist->Draw();

}