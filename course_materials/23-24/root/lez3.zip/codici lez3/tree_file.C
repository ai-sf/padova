
void tree_file() {
    // Creo file root
    TFile *file = new TFile("file2.root", "RECREATE");

    // Creo TTree da file 
    TTree *treeinput = new TTree("tree", "Tree da file"); 
    //Leggo il file e salvo nella colonna(Branch) var1
    treeinput->ReadFile("dati.txt", "var1");

    //più variabili
    // tree->ReadFile("file.txt", "var1:var2:var3");

    //Branch da vettore
    double v2[5] = {1, 2, 3, 4, 5};
    double x_input;
    treeinput->Branch("var2", &x_input);
    for (auto c: v2) {
        x_input = c;
        treeinput->Fill();
    }

    treeinput->Print();
    treeinput->Write();

    // Chiudo il file
    file->Close();

    //Leggere il file appena creato

    file = TFile::Open("file2.root", "READ");

    //Ottengo il TTree di nome "tree"
    TTree* tree = (TTree*)file->Get("tree");
    
    //Disegno un istogramma con i valori di var1

    TCanvas *c = new TCanvas();
    double min = tree->GetMinimum("var1");
    double max = tree->GetMaximum("var1");
    double nbin = 10;
    TH1F *histo = new TH1F("histo", "istogramma", nbin, min, max);
    //Disegno l'istogramma secondo le mie impostazioni
    tree->Draw("var1>>histo");

    //caso 2 colonne (grafico)
    // tree->Draw("var1:var2>>graph");

    c->SaveAs("histot.png");
    
    //Stampo i dati di var2
    tree->Scan("var2");
    //Stampo i dati >0.5
    tree->Scan("var2>2.5");
    Stampo la colonna var 2 i dati >0.5 e <0.8
    tree->Scan("var2", "var2>1.5 && var2<4.5");
    
    //Stampo con GetEntry

    double x;
    tree->SetBranchAddress("var2", &x_input);
    for (int i = 0; i < 5; i++) {
        tree->GetEntry(i);
        std::cout<<x<<"\n";
    }

}
