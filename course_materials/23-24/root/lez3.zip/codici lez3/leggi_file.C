void leggi_file() {
    // Apro il file ROOT in modalità di lettura
    TFile *file = new TFile("output.root", "READ");
    //funziona anche
    // TFile *file = TFile::Open("output.root","READ");

    // Leggo un istogramma dal file
    TH1F *hist= (TH1F*)file->Get("hist1"); //casting
    TCanvas *canvas = new TCanvas();
    hist->Draw();
    canvas->SaveAs("hist1.png");

}
