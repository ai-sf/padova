
void hist2d() {

    //Crea istogramma 2D
    TH2F *hist = new TH2F("2dhist", "Istogramma2D", 100, 30, 70, 100, 30, 70);
    //nbinx, xlow, xup, nbiny, ylow, yup

    //Leggi da file
    std::ifstream in("dati_h2d.txt");

    float x, y;
    while (in >> x >> y) {
        hist->Fill(x, y);
    }

    // Close the file
    in.close(); 
    TCanvas *canvas = new TCanvas(); 
    //Rimuovo legenda 
    hist->SetStats(0);
    //Imposto palette
    gStyle->SetPalette(kRainBow);
    hist->Draw("CONTZ");
    // hist->Draw("COLZ");
    canvas->SaveAs("hist2d.png");

}