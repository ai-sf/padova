void scrivi_file() {
    // Creo un nuovo file ROOT
    TFile *file = new TFile("file.root", "RECREATE");
    TCanvas *canvas = new TCanvas();

    // Creo un istogramma 
    TH1F *hist = new TH1F("hist", "Istogramma", 100, -10, 10);

    hist->FillRandom("gaus", 10000);
    hist->Draw();

    // Scrivo l'istogramma nel file
    hist->Write();

    //Creo grafico da array
    int n = 5;
    double x[] = {1, 2, 3, 4, 5};
    double y[] = {1, 4, 9, 16, 25};
    TGraph *graph = new TGraph(n, x, y);
    graph->Draw("APL*");


    //Scrivo il grafico nel file
    graph->Write("graph"); //nome a piacere

}