#include <iostream>
#include <fstream>
#include <vector>
#include <TH1F.h>
#include <TCanvas.h>

void hist() {
    // Apri il file contenente i dati
    std::ifstream infile("dati.txt");

    // Leggi i dati dal file e riempi un vettore
    std::vector<float> data_vec;
    float value;
    while (infile >> value) {
        data_vec.push_back(value);
    }
    infile.close();

    // Trova il minimo e il massimo dei dati
    float xmin = *min_element(data_vec.begin(), data_vec.end());
    float xmax = *max_element(data_vec.begin(), data_vec.end());

    // Crea un istogramma con i dati dal vettore
    int nBins = 10;
    TH1F *histogram = new TH1F("histogram", "Titolo dell'istogramma;Asse X;Asse Y", nBins, xmin, xmax);
    for (float data : data_vec) {
        histogram->Fill(data);
    }

    // Crea un canvas e disegna l'istogramma
    TCanvas *canvas = new TCanvas();
    histogram->Draw();

}

