void hello_world() {
    std::cout << "Hello, World!" << std::endl;
}
