#include <iostream>
#include <fstream>
#include <vector>
#include <TH1F.h>
#include <TCanvas.h>
#include <TF1.h>
#include <TFitResult.h>

void hist_fit() {
    // Apri il file contenente i dati
    std::ifstream infile("dati.txt");

    // Leggi i dati dal file e riempi un vettore
    std::vector<float> data_vec;
    float value;
    while (infile >> value) {
        data_vec.push_back(value);
    }
    infile.close();

    // Trova il minimo e il massimo dei dati
    float xmin = *min_element(data_vec.begin(), data_vec.end());
    float xmax = *max_element(data_vec.begin(), data_vec.end());

    // Crea un istogramma con i dati dal vettore
    int nBins = 10;
    TH1F *histogram = new TH1F("histogram", "Titolo dell'istogramma;Asse X;Asse Y", nBins, xmin, xmax);
    for (float data : data_vec) {
        histogram->Fill(data);
    }

    // Fai il fit dell'istogramma con una funzione gaussiana
    
    histogram->Fit("gaus");

    // Ottieni i parametri del fit
TF1 *fitFunction = histogram->GetFunction("gaus");
    double fitParameters[3] = fitFunction->GetParameters();

    // Stampa i parametri del fit
    std::cout << "Parametri del fit (a*exp(-(x-b)^2/(2*c^2))):" << std::endl;
    std::cout << "Ampiezza (a): " << fitParameters[0] << std::endl;
    std::cout << "Media (b): " << fitParameters[1] << std::endl;
    std::cout << "Deviazione standard (c): " << fitParameters[2] << std::endl;

    // Crea un canvas e disegna l'istogramma con il fit
    TCanvas *canvas = new TCanvas();
    histogram->Draw();

    // Salva l'istogramma con il fit in un file grafico
    canvas->SaveAs("istogramma_fit.png");

}

