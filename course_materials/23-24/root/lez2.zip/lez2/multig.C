void multig() {
    // Crea un oggetto TMultiGraph
    TCanvas *canvas = new TCanvas();
    TMultiGraph *mg = new TMultiGraph();
    mg->SetTitle("MultiGraph da File;Asse X;Asse Y");

    // Primo grafico
    TGraphErrors *graph1 = new TGraphErrors("dati_err.txt"); 
    graph1->SetTitle("Dati 1");
    graph1->SetMarkerColor(kBlue); 
    graph1->SetLineColor(kBlue); 
    graph1->SetMarkerStyle(20); 
    graph1->Fit("pol1"); 
    TF1 *fit_pol1 = graph1->GetFunction("pol1");
    fit_pol1->SetLineColor(kBlue);
    mg->Add(graph1);

    // Secondo grafico
    TGraphErrors *graph2 = new TGraphErrors("dati_err2.txt");
    graph2->SetTitle("Dati 2");
    graph2->SetMarkerColor(8); 
    graph2->SetLineColor(8); 
    graph2->SetMarkerStyle(21); 
    mg->Add(graph2);


    mg->Draw("ap"); //Senza * perché ho già usato setmarkerstyle

    // Aggiungo anche una funzione
    TF1 *func_sinx = new TF1("func_sinx", "sin(x)/x", 0, 10); 
    TGraph *graph_func_sinx = new TGraph(func_sinx);
    func_sinx->Draw("same");

    // Crea la legenda automaticamente
    //c->BuildLegend(); 
    
    //Manuale:
    TLegend *legend = new TLegend(0.1, 0.7, 0.3, 0.9);  
    // TLegend *legend = new TLegend();

    legend->AddEntry(graph1, "Dati 1");
    legend->AddEntry(fit_pol1, "Fit Dati 1");
    legend->AddEntry(graph2, "Dati 2");
    legend->AddEntry(graph_func_sinx, "Sin(x)/x");

    legend->Draw(); 


    canvas->SaveAs("multigraph.png");
    

}

