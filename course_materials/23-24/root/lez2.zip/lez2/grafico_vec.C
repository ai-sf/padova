
void grafico_vec() {
    // Apri il file di dati in lettura
    std::ifstream file("dati.txt");

    // Creazione di vettori per memorizzare i dati
    std::vector<double> x_vec, y_vec;
    double x, y;

    // Lettura dei dati dal file
    while (file >> x >> y) {
        x_vec.push_back(x);
        y_vec.push_back(y);
    }

    // Chiudi il file
    file.close();

    // Creazione di un TGraph con i dati letti
    TGraph *graph = new TGraph(x_vec.size(), &x_vec[0], &y_vec[0]); //da vector a semplici array con & 

    // Creazione di un canvas per visualizzare il grafico
    TCanvas *canvas = new TCanvas();
    graph->Draw("AP*");

}

