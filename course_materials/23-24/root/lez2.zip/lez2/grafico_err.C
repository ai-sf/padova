#include <TGraphErrors.h>
#include <TCanvas.h>
#include <TF1.h>
#include <TFitResult.h>
#include <TMatrixDSym.h>
#include <fstream> // Include per lo stream dei file
#include <string>


void grafico_err() {

    TCanvas *canvas = new TCanvas(); 

    const char* nomefile = "dati_err.txt";

    // Crea un oggetto TGraphErrors leggendo i dati da un file di testo
    TGraphErrors *grafico = new TGraphErrors(nomefile); 


    grafico->Draw("AP*"); 
    grafico->SetTitle("Grafico da File;Titolo asse x;Titolo asse y"); 

    // fit 
    auto dati_fit = grafico->Fit("pol1", "QS"); //classe TFitResultPtr
    // Q = non stampare risultati nel terminale
    // S = salvare i risultati del fit nella classe TFitResultPtr

    dati_fit->Print("V"); //stampa a schermo i risultati del fit

    canvas->SaveAs("grafico_err.png");
}

