void grafico_gaus_offset() {
    // Gaussiana + costante
    TCanvas *canvas = new TCanvas();
    TH1F *hist = new TH1F("hist", "Gaussiana con offset", 100, -10, 10);
    hist->FillRandom("gaus", 1000);
    hist->Draw();

    TF1 *gaus_offset = new TF1("gaus_offset", "gaus(0)+[3]", -10, 10);
//initial guess
    double std_dev_dati = hist->GetRMS();
    gaus_offset->SetParameter(2, std_dev_dati);

    hist->Fit("gaus_offset");
    // Get the fit function
    TF1 *gaus_plus_four = hist->GetFunction("gaus_offset");
    std::cout << "parametro\t valore\t errore\n";
    std::cout << "Ampiezza \t" << gaus_plus_four->GetParameter(0) << "\t" << gaus_plus_four->GetParError(0) << "\n";
    std::cout << "Media \t" << gaus_plus_four->GetParameter(1) << "\t" << gaus_plus_four->GetParError(1) << "\n";
    std::cout << "Dev Std\t" << gaus_plus_four->GetParameter(2) << "\t" << gaus_plus_four->GetParError(2) << "\n";
    std::cout << "offset \t" << gaus_plus_four->GetParameter(3) << "\t" << gaus_plus_four->GetParError(3) << "\n";
    canvas->SaveAs("hist_gaus_offset.png");


}