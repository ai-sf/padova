
void grafico() {

    const char* nomefile = "dati.txt"; // array di caratteri (stringa)

    // Crea TGraph leggendo i dati da un file di testo
    TGraph *grafico = new TGraph(nomefile); 
    
    // Crea una canvas per disegnare il grafico
    TCanvas *canvas = new TCanvas(); 

    // Disegna il grafico con errori
    grafico->Draw("AP*"); // A: disegna asse, *: mostra punti

    grafico->SetTitle("Grafico da file;Titolo asse x;Titolo asse y"); 
    grafico->Fit("pol1");

    // Salva la canvas come immagine
    canvas->SaveAs("grafico.png");

}

