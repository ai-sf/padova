
double Sin_offset(double *var, double *par) {
    double x = var[0];
    return par[0] * TMath::Sin(par[1] * x + par[2]) + par[3];
    // y = A * sin(B * x + C) + D
}

void grafico_sin_offset() {
    TCanvas *canvas = new TCanvas();
    TGraph *grafico = new TGraph("dati_sin.txt");
    TF1 *fFit = new TF1("fFit", Sin_offset, 0, 30, 4); // 4 è il numero di parametri!!! da mettere!!!!!
    fFit->SetParNames("A", "B", "C", "D");
    fFit->SetParameter(1,6);
    grafico->Fit("fFit");
    grafico->Draw("ap*");
    canvas->SaveAs("grafico_sin_offset.png");
}