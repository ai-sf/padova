#include <iostream>
#include <fstream>
#include <vector>
#include "TCanvas.h"
#include "TGraphErrors.h"
#include "TF1.h"
#include "TString.h"

using namespace std;

void graff_macro()
{
    // ===================================================
    // === PARTE 1: LA PRIMA MACRO IN ROOT ===============
    // ===================================================
    /*
    ROOT è un framework di analisi dati sviluppato al CERN, ampiamente utilizzato
    in fisica delle particelle e fisica nucleare. Una "macro" ROOT è essenzialmente
    un programma C++ con accesso alle librerie ROOT, permettendo analisi dati avanzate
    e visualizzazione grafica di alta qualità.
     */

    // Output a console per verificare che la macro funzioni correttamente
    cout << "Benvenuti in ROOT! Questa è la vostra prima macro." << endl;

    // ===================================================
    // === PARTE 2: IMPORTARE DATI DA FILE .TXT =========
    // ===================================================
    /*
    Nell'analisi dati in fisica, spesso i dati sperimentali sono memorizzati
    in file di testo. Questa sezione mostra come importare dati da un file .txt
    utilizzando le funzionalità standard di C++, prima di elaborarli con ROOT.
     */

    // Apertura del file in modalità lettura
    // Il file deve essere nella stessa directory della macro o specificato con percorso completo
    ifstream file("dati_macro1.txt");

    // Definiamo 4 vettori per memorizzare: valori x, valori y, errori su x, errori su y
    vector<double> x, y, errx, erry;
    double ascissa, ordinata, ascissaerr, ordinataerr;

    // Leggiamo il file riga per riga
    // Ogni riga contiene 4 valori: x, y, errore_x, errore_y
    // L'operatore >> estrae sequenzialmente i valori da ogni riga
    while (file >> ascissa >> ordinata >> ascissaerr >> ordinataerr)
    {
        // Aggiungiamo ogni valore letto al rispettivo vettore
        x.push_back(ascissa);        // Coordinata x del punto
        y.push_back(ordinata);       // Coordinata y del punto
        errx.push_back(ascissaerr);  // Incertezza sulla coordinata x
        erry.push_back(ordinataerr); // Incertezza sulla coordinata y
    }
    // Al termine del ciclo, i vettori contengono tutti i dati del file

    // ===================================================
    // === PARTE 3: CANVAS - DEFINIZIONE E UTILIZZO ======
    // ===================================================
    /*
    Il TCanvas è il componente fondamentale per la visualizzazione grafica in ROOT.
    Rappresenta l'area di disegno dove verranno visualizzati grafici, istogrammi e altri oggetti.
    */

    // Creazione di un nuovo canvas
    // Sintassi: new TCanvas("nome_interno", "titolo_visualizzato", larghezza, altezza)
    // Parametri:
    // - "nome_interno": identificativo usato da ROOT per riferirsi al canvas
    //   Se esiste già un canvas con lo stesso nome, ROOT lo sostituirà
    // - "titolo_visualizzato": titolo che apparirà sulla finestra del canvas
    // - larghezza, altezza: dimensioni in pixel (800x600 è il formato standard)
    // - Non è necessario che il nome della variabile coincida con il nome interno dell'oggetto
    TCanvas *canvas = new TCanvas("canvas", "Il mio primo Canvas", 800, 600);

    // Attivazione della griglia sul canvas per facilitare la lettura del grafico
    canvas->SetGrid();

    // ===================================================
    // ============== PARTE 4: GRAFICI ===================
    // ===================================================
    /*
    ROOT offre diverse classi per rappresentare dati su un grafico.
    TGraph è la classe base per grafici semplici (punti x,y).
    TGraphErrors estende TGraph per includere le incertezze (errori) sui punti.
     */

    // Creazione di un grafico semplice con la classe TGraph
    // Sintassi: new TGraph(numero_punti, array_x, array_y)
    // Parametri:
    // - numero_punti: quanti punti verranno visualizzati (deve essere un intero)
    // - array_x: puntatore al primo elemento dell'array contenente i valori x
    // - array_y: puntatore al primo elemento dell'array contenente i valori y
    TGraph *grafico1 = new TGraph(x.size(), &x[0], &y[0]);

    // NOTE TECNICHE:
    // - &x[0] è l'indirizzo del primo elemento del vettore x
    // - In C++11 e successivi, si può usare x.data() invece di &x[0]
    // - Per array tradizionali, la sintassi è semplicemente: new TGraph(n, x, y)

    // Visualizzazione del grafico
    // Draw() disegna l'oggetto sul canvas attivo
    // Le opzioni tra parentesi controllano l'aspetto del grafico:
    // - "A": disegna gli assi (Axes)
    // - "L": collega i punti con linee (Lines)
    // - "P": mostra i markers dei punti (Points)
    grafico1->Draw("ALP");

    // NOTA IMPORTANTE:
    // - Non è sempre necessario chiamare esplicitamente canvas->Draw()
    // - ROOT utilizzerà automaticamente l'ultimo canvas creato o attivato
    // - Se non esiste un canvas attivo, ROOT ne creerà uno temporaneo automaticamente

    // Creazione di un grafico con errori (TGraphErrors)
    // TGraphErrors estende TGraph includendo le incertezze sui dati
    // Sintassi: new TGraphErrors(numero_punti, array_x, array_y, array_errori_x, array_errori_y)
    // I primi tre parametri sono identici a TGraph, gli ultimi due specificano gli errori
    TGraphErrors *grafico2 = new TGraphErrors(x.size(), &x[0], &y[0], &errx[0], &erry[0]);

    // NOTE IMPORTANTI:
    // - Se non si vogliono errori sull'asse x, si può usare NULL, nullptr o 0 al posto di &errx[0]
    // - Gli errori vengono visualizzati come barre di errore sui punti

    // Aggiungiamo il secondo grafico allo stesso canvas
    // L'opzione "SAME" mantiene il grafico precedente e aggiunge il nuovo
    // Senza "SAME", il nuovo grafico sostituirebbe completamente quello precedente
    grafico2->Draw("SAME");

    // ===================================================
    // === PARTE 5: OPZIONI GRAFICHE =====================
    // ===================================================
    /*
    ROOT offre numerose funzioni per personalizzare l'aspetto dei grafici.
    È possibile modificare colori, stili, dimensioni e aggiungere titoli ed etichette.
     */

    // Impostazione dei titoli
    // Titolo principale del grafico (appare in alto)
    grafico1->SetTitle("Grafico semplice XY");

    // Titoli degli assi
    // Per accedere agli assi, si usano i metodi GetXaxis() e GetYaxis()
    // Poi si applica SetTitle() all'asse ottenuto
    grafico1->GetXaxis()->SetTitle("Asse X"); // Etichetta asse orizzontale
    grafico1->GetYaxis()->SetTitle("Asse Y"); // Etichetta asse verticale

    // Personalizzazione dei punti (markers)
    // Stile del marker (punto)
    // I valori numerici corrispondono a stili diversi:
    // 20 = cerchio pieno, 21 = quadrato pieno, 22 = triangolo pieno, ecc.
    // Per una lista completa degli stili, consultare la documentazione ROOT
    grafico1->SetMarkerStyle(20);

    // Dimensione del marker
    // Valori tipici: 0.8 (piccolo), 1.0 (default), 1.2-2.0 (più grande)
    grafico1->SetMarkerSize(1.2);

    // Personalizzazione dei colori
    // ROOT definisce costanti per i colori base: kRed, kBlue, kGreen, ecc.
    // Esistono anche varianti come kRed+1, kRed+2 (più chiaro) o kRed-1, kRed-2 (più scuro)
    grafico1->SetMarkerColor(kBlue);

    // Colore di riempimento (applicabile ad aree, non a punti singoli)
    grafico1->SetFillColor(kBlue);

    // Colore delle linee che collegano i punti
    grafico1->SetLineColor(kRed);

    // Spessore delle linee (in pixel)
    grafico1->SetLineWidth(2);

    // ===================================================
    // ============= PARTE 6: MULTIGRAPH =================
    // ===================================================
    /*
    La classe TMultiGraph permette di gestire e visualizzare più grafici
    contemporaneamente in modo coordinato. È utile per confrontare diversi
    set di dati sugli stessi assi, con legenda automatica e altre opzioni avanzate.
    Si differenzia dall'opzione "SAME" perché offre maggiore controllo e funzionalità.
    */

    // Creazione di un MultiGraph vuoto
    // A differenza di TGraph, non richiede dati al momento della creazione
    TMultiGraph *mg = new TMultiGraph();

    // Impostazione del titolo principale e dei titoli degli assi
    // Sintassi: "titolo_principale;titolo_asse_x;titolo_asse_y"
    // Questa sintassi compatta permette di impostare tutti e tre i titoli con una sola chiamata
    mg->SetTitle("Confronto tra due set di dati;Asse X;Asse Y");

    // Aggiunta dei grafici al MultiGraph
    // L'ordine di aggiunta influenza l'ordine di visualizzazione
    // Ogni grafico mantiene il proprio stile (colori, marker, ecc.)
    mg->Add(grafico1); // Primo grafico aggiunto
    mg->Add(grafico2); // Secondo grafico aggiunto

    // Visualizzazione del MultiGraph completo
    // Le stesse opzioni di Draw() viste prima sono applicabili anche qui
    mg->Draw("ALP");

    // NOTA IMPORTANTE:
    // - Quando si usa TMultiGraph, è il MultiGraph che controlla gli assi
    // - Le impostazioni degli assi devono essere applicate dopo Draw()
    // - È possibile accedere agli assi con mg->GetXaxis() e mg->GetYaxis()
}