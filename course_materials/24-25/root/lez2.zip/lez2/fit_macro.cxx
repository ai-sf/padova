#include "TCanvas.h"
#include "TGraph.h"
#include "TGraphErrors.h"
#include "TAxis.h"
#include "TMultiGraph.h"
#include "fstream"
#include "iostream"

using namespace std;

void fit_macro()
{
    // ===================================================
    // =============== PARTE 1: FUNZIONI =================
    // ===================================================
    /*
    In questa sezione introduciamo il concetto di funzioni in ROOT.
    ROOT consente di definire, personalizzare e visualizzare funzioni matematiche
    attraverso la classe TF1. Questo è fondamentale per i fit e le analisi dati.
     */

    // Creiamo un canvas dove visualizzare le nostre funzioni
    TCanvas *canvas = new TCanvas("canvas_funzioni", "Funzioni in ROOT", 900, 700);

    // Definizione di una funzione polinomiale del secondo grado: f(x) = 2x^2 + 3x - 5
    // Sintassi: TF1("nome_identificativo", "formula_matematica", x_minimo, x_massimo)
    // x_minimo e x_massimo definiscono il range di visualizzazione della funzione
    TF1 *f1 = new TF1("f1", "2*x*x + 3*x - 5", -5, 5);

    // La personalizzazione dell'aspetto grafico della funzione è lo stesso della classe TGraph
    f1->SetTitle("Funzione polinomiale"); // Titolo del grafico
    f1->GetXaxis()->SetTitle("x");        // Etichetta asse x
    f1->GetYaxis()->SetTitle("f(x)");     // Etichetta asse y
    f1->SetLineColor(kBlue);              // Colore della linea (costanti predefinite in ROOT)
    f1->SetLineWidth(2);                  // Spessore della linea

    // Visualizziamo la funzione sul canvas
    f1->Draw();

    // ===================================================
    // === 2. FUNZIONI CON PARAMETRI PERSONALIZZABILI ===
    // ===================================================
    /*
    Un potente strumento di ROOT è la possibilità di definire funzioni con parametri
    variabili, indicati con [n] dove n è l'indice del parametro (partendo da 0).
    Questo è essenziale per creare modelli da utilizzare nei fit.
    */

    // Definiamo una funzione sinusoidale: f(x) = [0]*sin([1]*x + [2])
    // dove:
    // [0] = ampiezza
    // [1] = frequenza angolare
    // [2] = fase
    TF1 *f2 = new TF1("f2", "[0]*sin([1]*x + [2])", -5, 5);

    // Inizializzazione dei parametri con SetParameter(indice, valore)
    f2->SetParameter(0, 2.0); // Ampiezza = 2.0
    f2->SetParameter(1, 1.5); // Frequenza = 1.5
    f2->SetParameter(2, 0.5); // Fase = 0.5

    // Assegnazione di nomi ai parametri per migliorare la leggibilità
    // Importante quando si lavora con funzioni complesse o nei report
    f2->SetParName(0, "Ampiezza");
    f2->SetParName(1, "Frequenza");
    f2->SetParName(2, "Fase");

    f2->SetLineColor(kRed); // Impostiamo un colore diverso per distinguerla

    // Aggiungiamo la funzione allo stesso canvas
    f2->Draw("SAME");

    // ===================================================
    // ===== PARTE 3: FUNZIONI GIÀ INCLUSE IN ROOT =======
    // ===================================================
    /*
    ROOT fornisce numerose funzioni predefinite per modellare distribuzioni comuni
    in fisica.
    Esempi: gaus (gaussiana), landau (distribuzione di Landau), expo (esponenziale),
     pol0-pol9 (polinomi di vario grado)
     */

    // Creiamo alcune funzioni predefinite per illustrarne l'uso
    TF1 *f4a = new TF1("f4a", "gaus", -5, 5);   // Gaussiana: parametri [0]=norm, [1]=media, [2]=sigma
    TF1 *f4b = new TF1("f4b", "expo", -5, 5);   // Esponenziale: exp([0] + x*[1])
    TF1 *f4c = new TF1("f4c", "landau", -5, 5); // Landau: distribuzione con lunga coda, [0]=MPV, [1]=sigma

    // Impostiamo parametri specifici per ciascuna funzione
    f4a->SetParameters(1, 0, 0.7); // Gaussiana: ampiezza=1, media=0, sigma=0.7
    f4b->SetParameters(0, -0.5);   // Esponenziale con decadimento: exp(0 + x*(-0.5))
    f4c->SetParameters(1, 0.5);    // Landau: MPV=1, sigma=0.5 (Most Probable Value)

    // Diversifichiamo i colori per facilitare l'identificazione
    f4a->SetLineColor(kBlue);
    f4b->SetLineColor(kRed);
    f4c->SetLineColor(kGreen);

    // Aggiungiamo le funzioni al canvas esistente
    f4a->SetTitle("Funzioni predefinite di ROOT");
    f4a->Draw("SAME");
    f4b->Draw("SAME");
    f4c->Draw("SAME");

    // ===================================================
    // ============ PARTE 4: FIT DI GRAFICI ==============
    // ===================================================
    /*
    ROOT fornisce potenti strumenti per adattare funzioni a set di dati e
    estrarre parametri fisici significativi con le relative incertezze.
     */

    // Creiamo un nuovo canvas per i fit, separando visivamente questa parte
    TCanvas *canvas_fit = new TCanvas("canvas_fit", "Fit di Grafici in ROOT", 900, 700);

    // Importiamo i dati
    ifstream file("dati_fitg.txt");

    vector<double> x, y, errx, erry;
    double ascissa, ordinata, ascissaerr, ordinataerr;

    while (file >> ascissa >> ordinata >> ascissaerr >> ordinataerr)
    {
        x.push_back(ascissa);        // Valore x
        y.push_back(ordinata);       // Valore y
        errx.push_back(ascissaerr);  // Errore su x
        erry.push_back(ordinataerr); // Errore su y
    }

    // Creiamo un TGraphErrors dai nostri dati
    TGraphErrors *g_err = new TGraphErrors(x.size(), &x[0], &y[0], &errx[0], &erry[0]);

    // Definiamo una funzione polinomiale di secondo grado per il fit
    // f(x) = [0] + [1]*x + [2]*x*x  (ovvero C + Bx + Ax^2)
    TF1 *fit_func = new TF1("fit_func", "[0] + [1]*x + [2]*x*x", x[0], x.size() - 1);

    // Eseguiamo il fit con il metodo Fit()
    // L'opzione "R" specifica di usare il range definito nella funzione per il fit
    // IMPORTANTE: per consentire a ROOT di realizzare il fit pesato sugli errori
    // utilizziamo l'opzione "E"
    g_err->Fit("fit_func", "RE");

    g_err->Draw("AP");

    // Stampiamo i risultati del fit a terminale per analisi
    cout << "=== Risultati del fit ===" << endl;
    // Il chi-quadro e gradi di libertà (NDF) sono richiamati con le funzioni GetChisquare e GetNDF
    cout << "Chi^2/NDF: " << fit_func->GetChisquare() << " / " << fit_func->GetNDF() << endl;

    // Stampiamo i parametri (funzione_fit -> GetParameter(indice_parametro)) ottenuti dal fit
    // con le loro incertezze (funzione_fit -> GetParError(indice_parametro))
    cout << "C: " << fit_func->GetParameter(0) << " +/- " << fit_func->GetParError(0) << endl;
    cout << "B: " << fit_func->GetParameter(1) << " +/- " << fit_func->GetParError(1) << endl;
    cout << "A: " << fit_func->GetParameter(2) << " +/- " << fit_func->GetParError(2) << endl;

    /*
    Spesso vogliamo salvare i parametri ottenuti dal fit per utilizzarli
    in altre analisi o per visualizzare la funzione altrove.
     */

    // Estraiamo i parametri in variabili separate
    double amp = fit_func->GetParameter(0);
    double mean = fit_func->GetParameter(1);
    double sigma = fit_func->GetParameter(2);

    // Creiamo ad esempio una nuova funzione usando i parametri ottenuti
    TF1 *saved_func = new TF1("saved_func", "gaus", -5, 5);
    saved_func->SetParameters(amp, mean, sigma);

    // ===================================================
    // === PARTE 5: ESPORTAZIONE DEI GRAFICI =============
    // ===================================================
    /*
    ROOT offre diverse modalità per esportare i grafici in vari formati,
    sia per pubblicazioni scientifiche che per presentazioni o report.
     */

    // --- 1. Esportazione programmata da macro ---
    // La funzione SaveAs() permette di salvare il canvas in diversi formati
    canvas_fit->SaveAs("grafico_esportato.png");  // Formato PNG - ideale per web/presentazioni
    canvas_fit->SaveAs("grafico_esportato.pdf");  // Formato PDF - ottimo per pubblicazioni
    canvas_fit->SaveAs("grafico_esportato.eps");  // Formato EPS - utilizzato in LaTeX
    canvas_fit->SaveAs("grafico_esportato.svg");  // Formato SVG - grafica vettoriale per web
    canvas_fit->SaveAs("grafico_esportato.C");    // Macro ROOT - per modifiche future
    canvas_fit->SaveAs("grafico_esportato.root"); // File ROOT - mantiene tutte le informazioni

    // --- 2. Informazioni sull'esportazione interattiva ---
    // Istruzioni per gli studenti che usano l'interfaccia grafica di ROOT
    // Per esportare interattivamente, fare click destro sul canvas
    // e selezionare 'Save As...' o 'Print...' dal menu contestuale
    // Si aprirà una finestra di dialogo per scegliere il formato e il percorso
}