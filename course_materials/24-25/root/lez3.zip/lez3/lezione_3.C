#include <fstream>
#include <iostream>
using namespace std;

//In questa macro vedremo:
// -riga 16: come disegnare istogrammi 1-dim e 2-dim a partire da dati salvati su un file .txt, come manipolare questi istogrammi e come
//      fare dei fit di questi. 
// -riga 147: come inserire informazioni statistiche (sia relative ai dati che a fit di dati) all'interno dei plot.
// -riga 168: come creare una legenda.
// -riga 193: opzioni grafiche varie per rendere un plot più leggibile e funzionale.
// -riga 240: come inserire più plot nella stessa figura (ad esempio per fare un grafico dei residui). 
// -riga 314: come aprire e manipolare file di tipo .root. 

void lezione_3(){

    // ======================================================
    // ====================  ISTOGRAMMI  ====================
    // ======================================================

    //IMPORTAZIONE DEI DATI

    //Importiamo i dati dai file tramite gli oggetti ifstream. Ci sono due file:
    //-"mark data.txt" contiene due colonne, con i voti e i rispettivi crediti degli esami di Fisica.
    //-"nuclear data.txt" contiene anch'esso due colonne, ognuna con varie misure ripetute dell'energia di un decadimento gamma. ATTENZIONE: questo file
    //contiene dati con ~11000 righe, quindi alcuni pc con poca ram potrebbero far fatica ad aprire il file con il blocco note di Windows. Io vi ho avvisati...
    ifstream infile_1;                              //Apriamo il file con i voti
	infile_1.open("mark data.txt");                 
    ifstream infile_2;                              //Apriamo il file con i dati di nucleare
	infile_2.open("nuclear data.txt");              
    if (!infile_1.is_open()) {                      //Check che il file sia stato trovato tramite il metodo is_open() di C++
        cout << "file \"mark data.txt\" not found " << endl;
        return;                                     //Per uscire dal programma; non possiamo mettere "return -1" perchè la funzione è di tipo void
    }
    if (!infile_2.is_open()) {                      
        cout << "file not found " << endl;
        return;                                 
    }

    //CREAZIONE E RIEMPIMENTO DEGLI ISTOGRAMMI CON I VOTI

    TH1D *h1 = new TH1D("h1", "titolo", 15, 17, 32);    //Definiamo l'oggetto istogramma per il plot dei voti tramite la tipica sintassi di ROOT
                                                        //TH1D: istogramma che prende in input double. Ci sono anche TH1I, TH1F, TH1B...
                                                        //I parametri sono: TH1D(nome, titolo, n_bin, x_min, x_max).
                                                        //Il nome è associato all'oggetto e può essere usato per cercarlo o recuperarlo da un file; in
                                                        //genere è consigliabile tenere lo stesso nome della variabile. Il titolo verrà disegnato
                                                        //assieme all'istogramma. x_min e x_max individuano il range sull'asse x in cui disegnare
                                                        //l'istogramma, n_bin è il numero di bin in cui verrà suddiviso questo range.
                                                        //NOTA: abbiamo definito l'oggetto come puntatore, quindi dovremo usare la sintassi h1->...
                                                        //DOCUMENTAZIONE: vedi classe TH1 e classi derivate (TH1D,TH1F...)
    //Vogliamo fare anche un plot bi-dimensionale per studiare la correlazione tra i voti e i crediti:
    TH2D *hcorr = new TH2D("hcorr", "correlation plot", 15, 17, 32, 9, 6, 15);      //In questo caso l'oggetto è TH2D <-> H(histogram) 2(2dim) con double(D).
                                                                                    //I parametri sono: TH2D(nome, titolo, n_bin_x, x_min, x_max,
                                                                                    //n_bin_y, y_min, y_max), ossia range e numero di bin sui due assi
                                                                                    //Qui abbiamo ad es. i voti sull'asse x in 15 bin nell'intervallo
                                                                                    //(17,32), e i crediti sull'asse y in 9 bin in (6,15).
    cout << "Il nome dell'istogramma appena definito è: " << h1->GetName() << endl;        //Un oggetto può essere identificato tramite il suo nome

    //Definiamo due variabili per prendere i dati in input dal primo file e usiamo un ciclo while per inserirli nell'istogramma
	double x,y;
	while(1){
        infile_1 >> x >> y;                             //Inseriamo i dati del file nelle variabili; x conterrà la prima colonna, y la seconda
        h1->Fill(x);                                    //Inseriamo ora i dati nell'istogramma
        hcorr->Fill(x,y);                               //Per l'ist. 2D inseriamo i voti (x) sull'asse x e i crediti (y) sull'asse y
        if(infile_1.eof()){                             //Quando raggiungiamo l'end of file (eof) usciamo dal while tramite un break
            break;
        }    
	}
	infile_1.close();

    //PLOT DEGLI ISTOGRAMMI APPENA CREATI

    TCanvas *c1 = new TCanvas("c1", "mark plot",0,0,600,500);           //Definiamo il canvas per fare il plot dei voti. I parametri dell'oggetto
                                                                        //TCanvas sono: nome dell'oggetto canvas (c1), titolo (mark plot) che verrà 
                                                                        //mostrato quando faremo il plot, coordinate del vertice in alto a sinistra
                                                                        //all'interno dello schermo, dimensione in pixel lungo x (600), dimensione 
                                                                        //in pixel lungo y (500). Le coordinate (0,0) si possono anche omettere e 
                                                                        //scrivere solamente TCanvas("c1", "mark plot",600,500), ma allora ROOT vi
                                                                        //disegnerà il canvas un po' a caso nello schermo
    h1->Draw();             //Disegniamo l'istogramma tramite il metodo Draw(). L'opzione di default è "hist", quindi h1->Draw() è equivalente a scrivere
                            //h1->Draw("hist"). Altre opzioni sono "e" (plot con errori),"func" (plot con funzione associata - se presente, ad esempio
                            //dopo un fit), "c" (disegna l'istogramma come una linea 'liscia'), "l" (disegna l'istogramma come una linea spezzata),
                            //"pie" (disegna l'istogramma come grafico a torta). Le opzioni possono esere scritte in maiuscolo o minuscolo 
                            //indifferentemente. DOCUMENTAZIONE: per altre opzioni vedere la classe THistPainter

    //Il plot 2D lo facciamo su un secondo canvas c2; questo permette di usare la stessa macro per fare più plot contemporaneamente. Ora però tutti i  
    //successivi comandi Draw() agiranno su questo canvas. Se volessimo disegnare qualcosa sul canvas c1 questo verrebbe disegnato su c2. 
    //Per tornare al canvas precedente (o comunque passare ad un canvas diverso) bisogna usare il comando c1->cd(): questo serve ad aggiornare
    //il canvas corrente (in questo esempio viene impostato c1 come current working canvas)
    TCanvas *c2 = new TCanvas("c2", "correlation plot",0,0,600,500);  
    hcorr->Draw("colz");            //Possibili opzioni per il plot: "col" è il default, "colz" per disegnare anche la scala colore, "box" o "box1" 
                                    //per disegnare dei quadrati, "lego" per lego plot, "arr" per le frecce, "candle" per candle plot, 
                                    //"surf" per una superficie. DOCUMENTAZIONE: vedi THistPainter

    //ISTOGRAMMI DI NUCLEARE E AZIONI VARIE SUGLI ISTOGRAMMI

    TH1D *h2 = new TH1D("h2", "nuc 1", 1500, 0, 1500);          //Creo due istogrammi nel range (0,1500) con 1500 bin
    TH1D *h3 = new TH1D("h3", "nuc 2", 1500, 0, 1500);

    double x_2,y_2;
	while(1){                           //Come prima per inserire i dati del file negli istogrammi
        infile_2 >> x_2 >> y_2;
        h2->Fill(x_2);
        h3->Fill(y_2);
        if(infile_2.eof()){
            break;
        }    
	}
	infile_2.close();
    
    TCanvas *c3 = new TCanvas("c3", "nuclear plot",0,0,600,500);        //Creaiamo un unico canvas e facciamo il plot sovrapposto dei due istogrammi

    h2->GetYaxis()->SetTitle("Counts");             //Impostiamo il titolo dell'asse y
    const char *titleX = "Energia (Joule)";         //Possiamo anche definire una variabile contente il titolo e poi inserirla in SetTitle(), ma
    h2->GetXaxis()->SetTitle(titleX);               //questa deve essere per forza un chonst char *, e non una string
    
    h2->SetLineColor(28);               //Cambiamo colore della linea dell'istogramma (ogni numero da 0 a 49 identifica un colore)
    h2->SetLineStyle(2);                //Mettiamo una linea tratteggiata invece che continua (opzioni da 1 a 10)
    h2->SetLineWidth(3);                //Cambiamo lo spessore della linea (qui i numeri indicano lo spessore in pixel). DOCUMENTAZIONE: TAttLine
    h3->SetFillColor(30);               //Impostiamo un colore di riempimento dell'area sotto l'istogramma
    h3->SetFillStyle(3001);             //Con questo comando possiamo cambiare il pattern di riempimento (solid, dashed...)
    h3->SetFillColorAlpha(30, 0.35);    //Imposta il colore 30 per l'area con un'opacità del 35%. DOCUMENTAZIONE: TAttFill

    double integrale = h2->Integral();              //Facciamo l'integrale dell'istogramma sull'intero range e lo salviamo in una variabile. Si può
                                                    //anche specificare il range con ad es. Integral(100,200)
	cout << "Integrale del primo istogramma: " << integrale << endl;
    h2->Scale( 1./integrale );          //La funzione Scale() permette di riscalare l'istogramma, moltiplicando tutti i bin per il numero che gli si 
    h3->Scale( 1./integrale );          //da in input. In questo caso stiamo dando 1/integrale così da normalizzare l'area dell'istogramma a 1.
                                        //NOTA: quando si chiama Scale() l'istogramma in seguito verrà disegnato con modalità "e" (quindi con gli errori);
                                        //usiamo quindi Draw("hist") per vedere l'istogramma come prima
    //h2->Rebin(10);                    //Per cambiare il numero di bin dell'istogramma; in questo caso unisce 10 bin in uno. Il numero di bin si
                                        //può solo ridurre e non aumentare
    
    h2->Draw("hist");
    h3->Draw("hist sames");     //"same" per disegnare l'istogramma sovrapposto, "sames" per includere anche la seconda Stat Box, che di default
                                //non viene disegnata. Il problema è che viene disegnata sopra quella precedente

    TF1 *gausfit = new TF1("gausfit","gaus",200,600);           //Definiamo una funzione gaussiana (con nome "gausfit") per il fit di h2, nel range 
                                                                //(200,600), usando la funzione predefinita di ROOT "gaus"
    TFitResultPtr r = h2->Fit("gausfit","SQ","hist",400,500);   //Facciamo il fit ma immagazziniamo il risultato in un oggetto TFitResult, che ci permette
                                                                //di accedere a vari parametri del fit, come chi quadro, matrice di covarianza...
                                                                //Per fare ciò dobbiamo usare l'opzione "S", altrimenti non funziona. Altre opzioni del fit
                                                                //sono "Q" per non stampare i risultati del fit nel terminale, "R" usa il range specificato
                                                                //nella funzione. Inoltre usiamo "hist" per disegnare solo l'istogramma senza la funzione
    cout << "Chi quadro: " << r->Chi2() << endl;        //Stampiamo il valore del chi quadro. DOCUMENTAZIONE: Fit::FitResult
    r->Print("V");                                      //Stampiamo tutti i risultati, incluse matrici di covarianza/correlazione

    // =========================================================
    // ====================  STATISTIC BOX  ====================
    // =========================================================

    //La statistic box permette di visualizzare velocemente alcuni parametri di un istogramma o il risultato di un fit, e viene disegnata in automatico

    //gStyle->SetOptStat(0);    //Questo comando può essere usato se si vogliono modificare tutte le stat box allo stesso modo (g(lobal)Style). Qua sotto 
                                //vediamo invece come agire in modo diverso sulle singole box
    hcorr->SetStats(0);         //Per togliere la stat box dal singolo istogramma

    c3->cd();                   //Ci mettiamo sul canvas 3 (qui non sarebbe necessario siccome è l'ultimo canvas definito)
    gPad->Update();             //Comando necessario affinchè in quello successivo venga trovato l'oggeto stats
    TPaveStats *st2 = (TPaveStats*)h2->FindObject("stats");     //Cerchiamo l'oggetto "stats" (ossia la stat box creata in automatico) nell'istogramma h2
                                                                //e lo salviamo nell'oggetto st2
    st2->SetX1NDC(0.72);        //Cambiamo l'ascissa dell'angolo in basso a sinistra. Conviene usare le coordinate NDC, ossia coordinate che vanno da
                                //0 a 1. Vedi https://root.cern/manual/graphics/#ndc
    st2->SetY1NDC(0.62);        //Idem per l'ordinata
    st2->SetOptStat(1101);      //Scegliamo quale statistica dell'istogramma plottare (Mean, RMS, entries, name). DOCUMENTAZIONE: TPaveStats
    st2->SetOptFit(111);        //Scegliamo di plottare chi2, parametri del fit ed errori di questi. DOCUMENTAZIONE: TPaveStats
    h3->SetStats(0);            //Rimuoviamo la stat box del secondo istogramma così che non copra quella appena modificata
    
    // ===================================================
    // ====================  LEGENDA  ====================
    // ===================================================

    //Definiamo un grafico con errori con 5 punti, a partire da un array di numeri
    double data_x[5] = {400,420,440,460,480};
    double data_y[5] = {0.002,0.003,0.011,0.007,0.004};
    double yerr[5] = {0.001,0.002,0.0005,0.0015,0.0005};
    double xerr[5] = {0,0,0,0,0};
    TGraphErrors *gr = new TGraphErrors(5,data_x,data_y,xerr,yerr);     
    gr->Draw("same p");             //disegniamo il grafico con dei punti (p) sovrapposto agli istogrammi (siamo sempre sul canvas c3)

    TLegend *lg = new TLegend(0.5, 0.3, 0.8, 0.6,"titolo legenda");     //Definiamo un oggetto legenda, con coordinate NDC in percentuale del canvas
                                                                        //(0.5, 0.4, 0.8, 0.7) = (x1, y1, x2, y2), con (x1, y1) angolo in basso a sinistra
                                                                        //e (x2, y2) angolo in alto a destra. Possiamo anche impostare un titolo
                                                                        //per la legenda. DOCUMENTAZIONE: TLegend
    lg->SetFillColor(0);            //Impostiamo il colore di riempimento, in questo caso bianco (0)
    lg->SetBorderSize(3);           //Impostiamo lo spessore del bordo. Si usa 0 per rimuovere il bordo
    lg->SetTextSize(0.04);          //Impostiamo le dimensioni del testo all'interno della legenda. Le dimensioni vengono date come frazione del pad corrente
    lg->AddEntry(h2, "Istogramma 1", "l");      //Aggiungiamo l'istogramma alla legenda, con opzione "l" che disegna la linea associata a h2
    lg->AddEntry(h3, "Istogramma 2", "fl");     //Opzione "fl" per disegnare linea e area associata
    lg->AddEntry(gausfit, "Fit #hbar", "l");    //Nel testo possiamo scrivere in Latex tramite # (vedi dopo per più info)
    lg->AddEntry(gr, "Grafico", "pe");          //Aggiungiamo il grafico con l'opzione "pe" per disegnare i punti con gli errori
    lg->Draw();                                 //Disegniamo la legenda all'interno del canvas
    
    // ============================================================
    // ====================  OPZIONI GRAFICHE  ====================
    // ============================================================

    //Vediamo come abbellire e rendere più presentabili una serie di risultati. NOTA: Le opzioni grafiche vanno modificate nel primo oggetto disegnato,
    //che in questo caso è h2 (qua ci riferiamo solamente al canvs c3)
    
    h2->SetTitle("dati nucleare");                  //Impostazione del titolo a posteriori
    h2->GetXaxis()->SetRangeUser(0,1400);           //SetRange() se si da il numero di bin, SetRangeUser() per le coordinate dell'asse x
    h2->GetYaxis()->SetRangeUser(0.0001,0.015);     //Facciamo lo stesso per l'asse y

    gr->SetMarkerStyle(21);         //Cambiamo i marker del grafico
    gr->SetMarkerSize(1.5);         //Il valore di default è 1, ed è un valore assoluto, non si riferisce a nessun sistema di coordinate. Sono
                                    //possibili anche valori decimali e <1. I marker 1, 6 e 7 hanno dimensione fissa. DOCUMENTAZIONE: TAttMArker
    gr->SetLineWidth(2);            //Su un grafico con marker "pieno" SetLineWidth() imposta lo spessore delle barre di errore

    //Proprietà degli assi
    h2->GetXaxis()->SetTitleSize(0.05);     //Cambiamo la dimensione del titolo sull'asse x; è data come percentuale delle dimensioni del pad/canvas 
    h2->GetXaxis()->SetTitleOffset(0.9);    //Distanza del titolo dall'asse. Il valore di riferimento è 1; 0.8 è l'80% di del valore di riferimento
    h2->GetXaxis()->SetLabelSize(0.05);     //Dimensioni dei numeri nell'asse. Sempre percentuale delle dimensioni del pad; il default è 0.035
    h2->GetXaxis()->SetNdivisions(4, kFALSE);      //Imposta le divisioni sull'asse. Se la seconda opzione è kFALSE usa esattamente 10 divisioni,
                                                    //altrimenti (kTRUE) trova un valore che permetta divisioni multiple di 100. DOCUMENTAZIONE: TAttAxis
    
    c3->SetTicky();         //Imposta i tick sull'asse y. DOCUMENTAZIONE: TPad
    c3->SetGrid();          //Imposta una griglia all'interno del canvas. SetGridx o SetGridy per grigle sui singoli assi
    //c3->SetLogy();        //Per avere l'asse y logaritmico

    //TESTO ALL'INTERNO DEL CANVAS

    //L'oggetto TPaveText disegna una box (TPave) con del testo all'interno
    TPaveText *pt = new TPaveText(0.2, 0.75, 0.7, 0.9,"NDC");           //(0.2, 0.75, 0.7, 0.9) = (x1, y1, x2, y2) con (x1, y1) e (x2, y2) come prima
                                                                        //Importante usare le coordinate NDC, altrimenti non si disegna
    pt->AddText("A TPaveText can contain severals line of text.");      //Aggiungiamo del testo all'interno, nella prima riga
    pt->AddText("Also Latex: #alpha + #beta = #theta #Rightarrow #sqrt{10^{3}}.");      //Possiamo usare anche comandi di Latex, tramite il simbolo #
    pt->Draw();                                                                         //Disegniamo la scatola. DOCUMENTAZIONE: TPaveText
    TLatex *text = new TLatex();                                //Esiste anche l'oggetto TLatex, con funzionamento analogo
    text->DrawLatexNDC(0.2, 0.4, "T=#frac{1}{2}mv^{2}");        //Disegna la formula nelle coordinate specificate. DOCUMENTAZIONE: TLatex

    // FUNCTION PLOT

    //Quando abbiamo fatto il fit abbiamo specificato "hist" nelle opzioni grafiche, così da non disegnare la funzione. La possiamo disegnare a posteriori
    //modificando alcuni parametri, come ad esempio il colore
    gausfit->SetLineColor(5);
    gausfit->Draw("same");

    c3->Print("plot nuc.png");      //Possiamo salvare il plot in un file tramite la funzione Print(), analoga a SaveAs(). DOCUMENTAZIONE: TPad
    
    // ================================================
    // ====================  PADS  ====================
    // ================================================

    //Il Pad è effettivamente l'oggetto su cui viene disegnato il plot. Ad ogni canvas viene associato un pad di default, e ogni canvas può contenere 
    //più pad al suo interno 

    //PAD PER GRAFICO DEI RESIDUI

    TCanvas *c4 = new TCanvas("c4", "pad demo",0,0,600,600);
    TPad *pad1 = new TPad("pad1", "pad1", 0, 0.33, 1, 1);       //Crerazione del Pad: nome, titolo e poi coordinate (x1, y1, x2, y2) dei punti in basso
                                                                //a sinistra e in alto a destra espressi nelle coordinate del canvas. In questo caso 
                                                                //disegniamo un pad nei due terzi superiori del canvas
    pad1->Draw();                               //Disegniamo il pad
    pad1->cd();                                 //Impostiamo pad1 come pad corrente, così che tutte le successive azioni avverrano su questo pad
    //pad1->SetMargin(0.15, 0.05, 0.4,0.08);    //Impostiamo tutti i margini, cioè la distanza dei bordi dai bordi del canvas; (Left, Right, Bottom, top). 
                                                //I margini vengono dati come frazione della larghezza del pad (left, right) e come frazione dell'altezza
                                                //del pad (bottom, top)
    pad1->SetBottomMargin(0.00001);             //Impostiamo il margine inferiore del pad singolarmente

    TH1D *h2_c = (TH1D*)h2->Clone();                //Cloniamo l'istogramma h2, così da poterlo modificare senza modificare anche l'originale h2; questa
                                                    //azione copia anche il titolo e tutti gli attributi. Se lo cloniamo prima di impostare tutte le
                                                    //impostazioni grafiche queste non verranno copiate
    h2_c->SetLineColor(46);             //Non modifica h2
    h3->SetLineColor(6);                //Cambia colore anche nel plot precedente

    h2_c->SetStats(0);
    h2_c->GetXaxis()->SetRangeUser(360,500);        //Facciamo uno zoom sul picco
    h2_c->Draw("hist");
    h3->Draw("hist sames");
    gausfit->Draw("same");
    gr->Draw("same p");

    c4->cd();                                                   //Passiamo dal pad1 al canvas c4
    TPad *pad2 = new TPad("pad2", "pad2", 0, 0, 1, 0.33);       //Definiamo il pad2 nella parte bassa del canvas c4
    pad2->Draw();                       
    pad2->cd();                         
    pad2->SetTopMargin(0.00001);                                //Mettiamo il margine così piccolo in modo da avere i pad affiancati in verticale

    //Calcoliamo i residui e immagazziniamoli in due vector che useremo poi per creare due grafici con errori
    vector<double> res_hv;
    vector<double> res_gv;
    for(int i=0; i<5; i++){
        res_hv.push_back( h2->GetBinContent(data_x[i]) - gausfit->Eval(data_x[i]) );    //Residui istogramma - funzione
        res_gv.push_back( data_y[i] - gausfit->Eval(data_x[i]) );                       //Residui punti - funzione
    }
    TGraphErrors *res_h = new TGraphErrors(5,&data_x[0],&res_hv[0],&xerr[0],&yerr[0]);      //NOTA: qui a rigore si dovrebbero mettere gli errori dei singoli
                                                                                            //bin dell'istogramma, a cui si può accedere tramite il metodo
                                                                                            //double erry = h->GetBinError(i);
    TGraphErrors *res_g = new TGraphErrors(5,&data_x[0],&res_gv[0],&xerr[0],&yerr[0]);

    //Cambiamo l'aspetto dei due grafici
    res_h->SetMarkerStyle(21);
    res_h->SetMarkerSize(1.5);              
    res_h->SetLineWidth(2);
    res_g->SetMarkerStyle(20);
    res_g->SetMarkerColor(2);
    res_g->SetLineColor(2);
    res_g->SetMarkerSize(1.5);
    res_g->SetLineWidth(2);
    res_h->SetTitle("");        //Non mettiamo niente come titolo dei grafico inferiore
    
    res_h->GetXaxis()->SetLimits(360,500);      //Per un grafico il range di visualizzazione su un asse si setta con la funzione SetLimits()
    res_h->Draw("p a");
    res_g->Draw("same p");

    // ZOOM PAD
    //I Pad possono essere utili anche per riservare una zona all'interno del canvas ad uno zoom di una certa parte del grafico che stiamo studiando
    //Il procedimento è sempre lo stesso: si definisce un nuovo pad all'interno del canvas o del pad precedente e su questo si disegna l'istogramma o
    //il grafico che si sta studiando (sempre clonandolo!) e poi si restringe il range di visualizzazione

    //Un'alternativa più veloce per dividere un canvas in varie sottoparti è usare la funzione Divide() (vedi la classe TPad). Questo metodo però 
    //è automatico e prevede meno possibilità di personalizzazione

    // ======================================================
    // ====================  ROOT FILES  ====================
    // ======================================================

    //ROOT permette di creare file in formato .root; questi file possono venire aperti solo tramite ROOT. AL loro interno possono contenere qualsiasi
    //tipo di oggetto (istogrammi, grafici, funzioni, canvas, risultati di fit...). Spesso però vengono usati per immagazzinare dati sperimentali,
    //sopratutto per quanto riguarda esperimenti di fisica nucleare e delle particelle. I dati vengono immagazzinati in una struttura chiamata Tree, 
    //che a sua volta può contenere le Branch e le Leaf. Questo permette di salvare i dati "per evento". Immaginiamo di fare 100 misure ripetute
    //della velocità di due corpi. Il Tree rappresenta tutta la nostra acquisizione dati, e avrà 100 entrate; le singole branch possono essere ad esempio 
    //le misure suddivise per i due corpi. All'interno delle branches possiamo avere poi una o più Leaves: ad esempio una Leaf può contenere le misure 
    //di tempo e un'altra può contenere misure di spazio. Possiamo quindi manipolare queste leaves, che sono quelle dove effettivamente sono salvate le 
    //misure, per ricavare le stime che ci interessano. I file .root possono essere esaminati da interfaccia grafica, mettendosi nel terminale di root
    //e invocando il Browser tramite il comando >new TBrowser, oppure anche con il TreeViewer

    //Creariamo un file .root in cui salveremo un istogramma, e in cui creaimo anche un Tree per far vedere poi come potervi accedere

    TFile *outfile = TFile::Open("FileOut.root", "recreate");       //Creaimo il file .root
    outfile->cd();
    h2->Write("istogramma");                                        //Scriviamo l'istogramma sul file 
    
    TTree tr("simpleTree", "esempio per dimostrare i TTree");       //Creaiamo il Tree
    double var;
    tr.Branch("branch", &var);  
    for (int iEntry = 0; iEntry < 10000; ++iEntry) {
        var = gRandom->Gaus(5,1);;
        tr.Fill();                                                  //Riempiamo il Tree con dei numeri generati
    }
    tr.Write();                                                     //Scriviamo il Tree sul file 
    outfile->Close();

    const char *file_name = "FileOut.root";                         //Apriamo il file .root appena creato
    TFile infile(file_name);
    if (infile.IsZombie()){
        cout << "Cannot open root file: " << file_name << endl;
        exit(-1);
    }
    TH1D *h4;
    h4 = (TH1D*)infile.Get("istogramma");                           //Cerchiamo l'istogramma (tramite il suo nome) all'interno del file
    h4->SetDirectory(0);                                            
    infile.Close();

    TCanvas *c5 = new TCanvas("c5", "root file demo",0,0,600,500);
    h4->Draw("hist");                                               //Facciamo un plot dell'istogramma appena trovato

}